// import Button from './components/classBasedButton';
// import {Game, Heading} from './components/Headings';
import './App.css'
import Bio from './components/Bio';
import Eligible from './components/conditionalRendering';
// import Play from './components/eventHandler';
// import Counter from './components/Counter';

function App() {
  return (
    <>
      <div className='appContainer'>
        {/* <Game />
        <Heading />
        <Button /> */}
        {/* <Play/> */}
        
        {/* <Counter/> */}
        <Bio />
        {/* <Eligible /> */}

      </div>
    </>
  )
}

export default App;